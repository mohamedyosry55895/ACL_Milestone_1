# =========================
# MAIN PIPELINE (STEP 2–6)
# =========================

# ---------- Step 2: Preprocessing ----------
from preprocessing.intent_classifier import classify_intent
from preprocessing.entity_extraction import extract_entities

# ---------- Step 3: Baseline Retrieval ----------
from retrieval.query_router import select_query

# ---------- Step 4: Neo4j ----------
from db.neo4j_connector import Neo4jConnector
from config import NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD

# ---------- Step 5: Embeddings ----------
from embeddings.embedder import TextEmbedder
from embeddings.vector_store import VectorStore

# ---------- Step 6: LLM (Graph-RAG) ----------
from llm.prompt_builder import build_prompt
from llm.llm_runner import OpenAILLM


def main():
    # =========================
    # USER QUERY
    # =========================
    user_query = "Which flights from Cairo to Dubai have high delays?"

    print("\nUSER QUERY:")
    print(user_query)

    # =========================
    # STEP 2: INTENT + ENTITIES
    # =========================
    intent = classify_intent(user_query)
    entities = extract_entities(user_query)

    print("\nINTENT:")
    print(intent)

    print("\nENTITIES:")
    print(entities)

    # =========================
    # STEP 3: SELECT CYPHER QUERY
    # =========================
    cypher_query, params = select_query(intent, entities)

    print("\nCYPHER QUERY:")
    print(cypher_query)

    print("\nPARAMETERS:")
    print(params)

    # =========================
    # STEP 4: EXECUTE CYPHER
    # =========================
    neo4j = Neo4jConnector(
        uri=NEO4J_URI,
        user=NEO4J_USER,
        password=NEO4J_PASSWORD
    )

    cypher_results = neo4j.run_query(cypher_query, params)
    neo4j.close()

    print("\nCYPHER RESULTS:")
    for r in cypher_results:
        print(r)

    # =========================
    # STEP 5: EMBEDDING RETRIEVAL
    # =========================

    # Fetch data again to build text embeddings
    neo4j = Neo4jConnector(
        uri=NEO4J_URI,
        user=NEO4J_USER,
        password=NEO4J_PASSWORD
    )

    flight_rows = neo4j.run_query("""
    MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
    RETURN
        f.flight_id AS flight_id,
        f.airline AS airline,
        r.origin AS origin,
        r.destination AS destination,
        f.delay_minutes AS delay
    """)

    neo4j.close()

    texts = [
        f"Flight {r['flight_id']} by {r['airline']} operates from {r['origin']} to {r['destination']} with delay {r['delay']} minutes."
        for r in flight_rows
    ]

    print("\nTEXTS TO EMBED:")
    for t in texts:
        print("-", t)

    # ---- Choose embedding model (MiniLM or MPNet) ----
    embedder = TextEmbedder("sentence-transformers/all-MiniLM-L6-v2")
    # embedder = TextEmbedder("sentence-transformers/all-mpnet-base-v2")

    embeddings = embedder.embed_texts(texts)

    store = VectorStore(embeddings.shape[1])
    store.add(embeddings, texts)

    query_embedding = embedder.embed_query(user_query)
    embedding_results = store.search(query_embedding, k=2)

    print("\nEMBEDDING RETRIEVAL RESULTS:")
    for r in embedding_results:
        print("-", r)

    # =========================
    # STEP 6: GRAPH-RAG LLM
    # =========================
    prompt = build_prompt(
        user_query=user_query,
        cypher_results=cypher_results,
        embedding_results=embedding_results
    )

    print("\n--- LLM PROMPT ---")
    print(prompt)

    # ---- OpenAI LLM ----
    llm = OpenAILLM(model="gpt-3.5-turbo")  # or "gpt-4"
    response = llm.generate(prompt)

    print("\n--- LLM RESPONSE (OpenAI) ---")
    print(response)


if __name__ == "__main__":
    main()
