from sentence_transformers import SentenceTransformer

class TextEmbedder:
    def __init__(self, model_name: str):
        self.model = SentenceTransformer(model_name)

    def embed_texts(self, texts):
        return self.model.encode(texts, convert_to_numpy=True)

    def embed_query(self, query: str):
        return self.model.encode([query], convert_to_numpy=True)
