def classify_intent(query: str) -> str:
    q = query.lower()

    if any(word in q for word in ["route", "routes", "from", "to"]):
        return "route_performance"

    if any(word in q for word in ["delay", "delayed", "late"]):
        return "flight_delay_analysis"

    if any(word in q for word in ["satisfaction", "rating", "rated", "review"]):
        return "satisfaction_analysis"

    if any(word in q for word in ["class", "economy", "business", "first"]):
        return "class_analysis"

    if any(word in q for word in ["flight", "flight id", "flight number"]):
        return "flight_lookup"

    return "unknown"
