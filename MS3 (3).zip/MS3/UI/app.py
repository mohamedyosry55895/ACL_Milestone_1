import streamlit as st

# ---- Import your pipeline components ----
from preprocessing.intent_classifier import classify_intent
from preprocessing.entity_extraction import extract_entities
from retrieval.query_router import select_query
from db.neo4j_connector import Neo4jConnector
from embeddings.embedder import TextEmbedder
from embeddings.vector_store import VectorStore
from llm.prompt_builder import build_prompt
from llm.llm_runner import OpenAILLM
from config import NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD


st.set_page_config(page_title="Airline Graph-RAG", layout="wide")

st.title("✈️ Airline Graph-RAG System")
st.write("Natural Language Querying over an Airline Knowledge Graph")

# -------------------------------
# User Input
# -------------------------------
user_query = st.text_input(
    "Enter your query:",
    value="Which flights from Cairo to Dubai have high delays?"
)

run_button = st.button("Run Query")

if run_button and user_query:

    # -------------------------------
    # Step 2: NLP
    # -------------------------------
    intent = classify_intent(user_query)
    entities = extract_entities(user_query)

    st.subheader("🧠 Intent & Entities")
    st.write("**Intent:**", intent)
    st.json(entities)

    # -------------------------------
    # Step 3: Cypher
    # -------------------------------
    cypher_query, params = select_query(intent, entities)

    st.subheader("🗃️ Cypher Query")
    st.code(cypher_query)
    st.write("**Parameters:**", params)

    # -------------------------------
    # Step 4: Neo4j Execution
    # -------------------------------
    neo4j = Neo4jConnector(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD)
    cypher_results = neo4j.run_query(cypher_query, params)

    st.subheader("📊 Cypher Results")
    if cypher_results:
        st.table(cypher_results)
    else:
        st.warning("No results returned from Neo4j.")

    # -------------------------------
    # Step 5: Embedding Retrieval
    # -------------------------------
    flight_rows = neo4j.run_query("""
    MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
    RETURN
        f.flight_id AS flight_id,
        f.airline AS airline,
        r.origin AS origin,
        r.destination AS destination,
        f.delay_minutes AS delay
    """)

    neo4j.close()

    texts = [
        f"Flight {r['flight_id']} by {r['airline']} operates from {r['origin']} to {r['destination']} with delay {r['delay']} minutes."
        for r in flight_rows
    ]

    embedder = TextEmbedder("sentence-transformers/all-MiniLM-L6-v2")
    embeddings = embedder.embed_texts(texts)

    store = VectorStore(embeddings.shape[1])
    store.add(embeddings, texts)

    query_embedding = embedder.embed_query(user_query)
    embedding_results = store.search(query_embedding, k=2)

    st.subheader("🔍 Embedding Retrieval Results")
    for r in embedding_results:
        st.write("-", r)

    # -------------------------------
    # Step 6: Graph-RAG LLM
    # -------------------------------
    prompt = build_prompt(
        user_query=user_query,
        cypher_results=cypher_results,
        embedding_results=embedding_results
    )

    st.subheader("🧾 LLM Prompt (Graph-RAG)")
    st.text_area("Prompt", prompt, height=300)

    llm = OpenAILLM(model="gpt-3.5-turbo")
    response = llm.generate(prompt)

    st.subheader("🤖 LLM Response")
    st.write(response)
