def select_query(intent, entities):
    if intent in ["route_performance", "flight_delay_analysis","flight_lookup"]:
        origin, destination = entities["airports"]
        delay = entities.get("delay_minutes")

        # 🔴 LOW DELAYS
        if delay is not None and delay <= 20:
            query = """
            MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
            WHERE r.origin = $origin
              AND r.destination = $destination
              AND f.delay_minutes <= $delay
            RETURN
                f.flight_id AS flight_id,
                f.delay_minutes AS delay_minutes
            ORDER BY delay_minutes ASC
            """
            params = {
                "origin": origin,
                "destination": destination,
                "delay": delay
            }
            return query, params

        # 🔴 HIGH DELAYS
        if delay is not None and delay > 15:
            query = """
            MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
            WHERE r.origin = $origin
              AND r.destination = $destination
              AND f.delay_minutes > $delay
            RETURN
                f.flight_id AS flight_id,
                f.delay_minutes AS delay_minutes
            ORDER BY delay_minutes DESC
            """
            params = {
                "origin": origin,
                "destination": destination,
                "delay": delay
            }
            return query, params

        # 🔴 NO DELAY THRESHOLD
        query = """
        MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
        WHERE r.origin = $origin
          AND r.destination = $destination
        RETURN
            f.flight_id AS flight_id,
            f.delay_minutes AS delay_minutes
        ORDER BY delay_minutes DESC
        """
        params = {
            "origin": origin,
            "destination": destination
        }
        return query, params
    
    return None, {}
