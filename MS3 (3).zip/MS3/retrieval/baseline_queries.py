BASELINE_QUERIES = {

    # 1. Routes with highest average delay
    "worst_routes_by_delay": """
    MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
    RETURN r.origin AS origin, r.destination AS destination,
           AVG(f.delay_minutes) AS avg_delay
    ORDER BY avg_delay DESC
    LIMIT 5
    """,

    # 2. Flights delayed more than X minutes
    "flights_with_high_delay": """
    MATCH (f:Flight)
    WHERE f.delay_minutes > $delay
    RETURN f.flight_id, f.delay_minutes
    ORDER BY f.delay_minutes DESC
    """,

    # 3. Worst routes by satisfaction
    "worst_routes_by_satisfaction": """
    MATCH (j:Journey)-[:ON_FLIGHT]->(f:Flight)-[:OPERATES_ON]->(r:Route)
    RETURN r.origin AS origin, r.destination AS destination,
           AVG(j.satisfaction_score) AS avg_satisfaction
    ORDER BY avg_satisfaction ASC
    LIMIT 5
    """,

    # 4. Best routes by satisfaction
    "best_routes_by_satisfaction": """
    MATCH (j:Journey)-[:ON_FLIGHT]->(f:Flight)-[:OPERATES_ON]->(r:Route)
    RETURN r.origin AS origin, r.destination AS destination,
           AVG(j.satisfaction_score) AS avg_satisfaction
    ORDER BY avg_satisfaction DESC
    LIMIT 5
    """,

    # 5. Route performance between two airports
        "route_between_airports": """
    MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
    WHERE r.origin = $origin AND r.destination = $destination
    RETURN
        f.flight_id AS flight_id,
        f.delay_minutes AS delay_minutes
    ORDER BY delay_minutes DESC
    """,


    # 6. Average delay per airline
    "avg_delay_per_airline": """
    MATCH (f:Flight)
    RETURN f.airline AS airline, AVG(f.delay_minutes) AS avg_delay
    ORDER BY avg_delay DESC
    """,

    # 7. Satisfaction per cabin class
    "satisfaction_per_class": """
    MATCH (j:Journey)
    RETURN j.class AS cabin_class,
           AVG(j.satisfaction_score) AS avg_satisfaction
    ORDER BY avg_satisfaction ASC
    """,

    # 8. Flights with high delay AND low satisfaction
    "problematic_flights": """
    MATCH (j:Journey)-[:ON_FLIGHT]->(f:Flight)
    WHERE f.delay_minutes > 30 AND j.satisfaction_score < 3
    RETURN f.flight_id, f.delay_minutes, j.satisfaction_score
    ORDER BY f.delay_minutes DESC
    """,

    # 9. Most problematic airports (by delays)
    "problematic_airports": """
    MATCH (f:Flight)-[:OPERATES_ON]->(r:Route)
    RETURN r.origin AS airport, AVG(f.delay_minutes) AS avg_delay
    ORDER BY avg_delay DESC
    LIMIT 5
    """,

    # 10. Specific flight lookup
    "flight_lookup": """
    MATCH (f:Flight)
    WHERE f.flight_id = $flight_id
    RETURN f.flight_id, f.airline, f.delay_minutes
    """
}
