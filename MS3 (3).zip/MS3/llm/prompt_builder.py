def build_prompt(user_query, cypher_results, embedding_results):
    context = "GRAPH CONTEXT:\n"

    if cypher_results:
        context += "Structured KG Results:\n"
        for r in cypher_results:
            context += f"- Flight {r['flight_id']} has delay {r['delay_minutes']} minutes.\n"

    if embedding_results:
        context += "\nSemantic Retrieval Results:\n"
        for r in embedding_results:
            context += f"- {r}\n"

    persona = (
        "You are an airline operations analyst. "
        "You analyze flight delays and route performance for decision making."
    )

    task = (
        "Answer the user question using ONLY the information provided above. "
        "Do not add external knowledge. Be concise and factual."
    )

    prompt = f"""
{persona}

{context}

USER QUESTION:
{user_query}

TASK:
{task}
"""

    return prompt
