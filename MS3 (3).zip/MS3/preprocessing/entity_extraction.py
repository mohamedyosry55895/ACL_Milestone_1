import spacy
import re

nlp = spacy.load("en_core_web_sm")

CITY_TO_AIRPORT = {
    "cairo": "CAI",
    "dubai": "DXB",
    "london": "LHR",
    "new york": "JFK"
}

def extract_entities(query: str) -> dict:
    doc = nlp(query)
    text_lower = query.lower()

    entities = {
        "airports": [],
        "flight_ids": [],
        "airlines": [],
        "classes": [],
        "delay_minutes": None
    }

    # -------- spaCy NER (Airlines only) --------
    for ent in doc.ents:
        if ent.label_ == "ORG":
            # Avoid misclassifying airport codes as airlines
            if not re.fullmatch(r"[A-Z]{3}", ent.text):
                entities["airlines"].append(ent.text)

    # -------- Explicit airport codes (CAI, DXB) --------
    entities["airports"].extend(re.findall(r"\b[A-Z]{3}\b", query))

    # -------- City → Airport mapping --------
    for city, airport_code in CITY_TO_AIRPORT.items():
        if city in text_lower:
            entities["airports"].append(airport_code)

    # -------- Flight IDs (EK202, BA105) --------
    entities["flight_ids"].extend(
        re.findall(r"\b[A-Z]{2}\d{2,4}\b", query)
    )

    # -------- Cabin class --------
    if re.search(r"\beconomy\b", query, re.I):
        entities["classes"].append("Economy")
    if re.search(r"\bbusiness\b", query, re.I):
        entities["classes"].append("Business")
    if re.search(r"\bfirst\b", query, re.I):
        entities["classes"].append("First")

    # -------- Delay threshold --------
    delay_match = re.search(r"(\d+)\s*minutes", query)
    if delay_match:
        entities["delay_minutes"] = int(delay_match.group(1))

    if "severe delay" in text_lower or "severely delayed" in text_lower:
        entities["delay_minutes"] = 30

    elif "high delay" in text_lower or "high delays" in text_lower:
        entities["delay_minutes"] = 30

    elif "low delay" in text_lower or "low delays" in text_lower:
        entities["delay_minutes"] = 10

    # -------- Direction-aware route extraction (from X to Y) --------
    origin = None
    destination = None

    for city, code in CITY_TO_AIRPORT.items():
        if f"from {city}" in text_lower:
            origin = code
        if f"to {city}" in text_lower:
            destination = code

    # If direction detected, override airport order
    if origin and destination:
        entities["airports"] = [origin, destination]
    else:
        # Otherwise, deduplicate but preserve order
        seen = set()
        ordered_airports = []
        for a in entities["airports"]:
            if a not in seen:
                seen.add(a)
                ordered_airports.append(a)
        entities["airports"] = ordered_airports

    # -------- Final deduplication --------
    entities["airlines"] = list(set(entities["airlines"]))
    entities["flight_ids"] = list(set(entities["flight_ids"]))
    entities["classes"] = list(set(entities["classes"]))

    return entities
